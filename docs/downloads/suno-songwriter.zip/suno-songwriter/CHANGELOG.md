# Changelog

## Unreleased

### Added

- Verified against Suno's own pages, read directly on 2026-11-04: the v6 FAQ, Current Models, What's New in v6, Voices, and Custom Models help articles, the v6 announcement, and the full release notes.
- `references/suno-speech.md` and a `Title` / `Script` / `Voice` / `Music` output for Speech (beta), the 2026-10-01 mode that generates narration and its soundtrack together, with routing between Speech and `[Spoken]` sections in songs.
- Suno MCP (beta, 2026-10-28) guidance in `SKILL.md`: submit a finished package only when a Suno connector is actually available and the credit spend is confirmed; otherwise return text and never claim generation.
- Suno's own v6 example requests (plain-language section edits, mashups, sample-and-isolate, vibe, multimodal, single-lyric edits) as phrasing models in the controls reference.
- Later Studio releases and the Studio Chat assistant, album publishing and team workspaces, and regression cases `MD15`-`MD17`.

### Fixed

- Custom Models: Suno's What's New page states they fine-tune v6, so removed the claim that the base was unconfirmed. Recorded that the 2026-10-15 release notes made them shareable on Premier, superseding the help article's "private".
- Voices: updated to the current article (15 seconds to 4 minutes of audio, best 2 minutes chosen, voice from a library song, select in the model dropdown, keep Audio Influence high) and to free-plan availability from 2026-08-07.

- A `What Changed From v5.5` table in `references/suno-v6-controls.md`, from a 2026-11-04 survey of Suno's v6 pages and community v6 test reports: models, length, connected-language Style prompts, Variety rewriting, take variance, section cues, plain-language edits, multimodal inputs, Voices, Max Mode, and training-data provenance. Documented and reported items are labeled separately.
- `v6 Section Cues` in `references/suno-meta-tags.md`: v6 reportedly acts on short delivery, language, and energy direction inside a section header (`[Bridge | whispered, in French]`). The pipe form is now accepted alongside the hyphen form, with guidance to mirror essential changes in Style and to avoid coined tag syntax, which is reported to be dropped.
- Community-reported v6 slider defaults (Weirdness 50, Style Influence 50, Audio Influence 25), the five Variety stops with per-model defaults now reported by several guides, and a 54-take test showing Variety Off preserved the Style text on 52 of 54 takes while Normal rewrote it every time.
- `Vocal Delivery And Lyric Density` in `references/v6-production-direction.md` for the common rushed or flat v6 vocal complaint: check rendered tempo, then syllable load; `[Silence]` and hyphenation tricks are labeled anecdotal.
- Reported v6 Voices and Custom Models details (Upgrade Voice to v6, no Voices on instrumentals, Max Mode recommended with a Voice, 100-credit Custom Model Beta) in `references/personas.md` and the controls reference.
- Regression cases `MD11`-`MD14` covering ported v5.5 tag stacks, per-section language cues, rushed vocals, and take variance versus prompt edits.

- A structured 16-case songwriting and fusion benchmark with synthetic original inputs, an independent judging protocol, anchored quality scores, and revision-comparison guidance. No real Suno data is required; behavioral results are pending.

- Five genre-writing family references and a coverage router, with lane-specific phrasing, hook, form, and arrangement decisions.
- Deeper songwriting craft: speaker and angle, narrative consequence, hook design, prosody, rhyme architecture, subtext, and targeted revision.
- A role-based genre-fusion workflow with pulse/meter conflict resolution, multi-influence blends, transition design, and exact-lyric version handling.
- A Writing by Genre website page and updated lyric, fusion, workflow, and reference pages.
- Seventeen songwriting/fusion regression scenarios spanning non-pop forms and mixed genres.

- Practical harmony/melody and rhythm/arrangement references, routed from the skill and docs, with musical intent translated into prompt examples.
- Music-knowledge regression prompts for compound meter, modal color, vocal range, arrangement contrast, and controlled v6 comparisons.

- Suno v6 model guidance: `v6`, `v6-wild`, and `v6-mini` selection criteria, the 8-minute per-generation ceiling, and Max Mode cost and timing, in `references/suno-v6-controls.md`.
- Variety slider coverage: it can rewrite the style prompt before generation; set it to 0 for any A/B comparison, persona, or album that depends on exact Style text.
- `references/v6-production-direction.md`: community field notes on directing the performance and the mix, covering instrument activity verbs, vocal character, verse energy, production clauses, ending buffers, and the labeled directed brief as an alternative to a compact Style line.
- A `Say The Plain Meaning First` rule in `references/songwriting-craft.md`, plus cases `PM1` and `PM2`. Asked what a lyric meant, the skill produced an elaborate symbolic reading and inverted the song's actual arc; the plain reading was correct and was never stated. The rule requires one plain sentence before any analysis, tests each device against it, and leads with the plain reading whenever both fit.
- A `Pre-Output Check` in `SKILL.md`, plus regression cases `PO1`-`PO4`. Two packages generated by the previous skill version were reviewed against their own rules: one put an `exclude:` list and a stray `trap` token inside `Style`, and inverted a bridge parenthetical so the production direction sat where the sung words belong; the other carried a reused `Style` line that still promised a spoken French bridge the new lyric did not contain, and used an en-dash in seven of nine section tags. The rules those outputs broke were already stated in `SKILL.md`, so the fix reads the finished fields against each other rather than adding more drafting prose.
- Download budget guidance in `references/studio-and-iteration.md`. Downloads became a resource capped separately from credits on 2026-09-03 (7 lifetime on Free, 20/month Pro, 60/month Premier, Premier Studio exports uncapped), so the skill now treats deciding rather than generating as the expensive step and raises the cost before recommending a multi-download workflow.
- A pre-v6 compatibility section: listen, share, Remaster, Cover, Extend, and Remix are officially guaranteed on songs made with retired models and all re-render on v6; Replace Section, Crop, stems, and the new plain-language editing are undocumented on old songs and are reported as such.
- v6 reference inputs in `references/suno-v6-controls.md`: Suno songs, playlists, audio uploads, images, video, and voice memos, plus mashups and sample-and-isolate. Suno documents that these exist but not their control names, so the skill describes intent instead of naming fields it cannot verify. `Inspire` / `+Inspo` is recorded as the separate, older playlist feature it is.
- Vocal Gender (Male and Female, the only documented values) and the Magic Wand's location at the top right of the Styles box.
- Ten platform regression cases (`MD1`-`MD10`) in `references/evals.md` covering retired-model requests, Variety-driven take variance, Max Mode timing, split production faults, mid-lyric cutoffs, and free-plan routing.
- Download Skill ZIP buttons on the docs Overview and Quick Start pages, a bundled archive, and a reproducible packaging script with a stale-archive check.

- Web documentation page on prompting for songs: reusable briefs, hook exploration, full songs, focused rewrites, instrumentals, adaptation, and actionable iteration feedback.

- Song matrix reference: section jobs, hook and arrangement contrast, prosody, bar/time budgets, and diagnosis.
- Audio Influence guidance, a take comparison log and stopping rule, and Studio 2.0 MIDI/automation routing with official sources checked 2026-09-05.

### Changed

- Retargeted the skill from Suno v5.5 to Suno v6 across `SKILL.md`, `references/`, `README.md`, `agents/openai.yaml`, and the docs site. Suno retired every pre-v6 model on 2026-09-09, so v5.5 and earlier no longer generate new material; the verification stamp is now 2026-09-13.
- Renamed `references/suno-v55-controls.md` to `references/suno-v6-controls.md` and the optional `Suno v5.5 Notes` output field to `Suno v6 Notes`.
- Renamed Custom Mode to Advanced throughout, matching the shipped v6 Create page. Suno's Custom Mode help article still describes a Custom toggle and is behind the UI; `references/suno-v6-controls.md` records that so the naming is not reverted to match the stale article. `Custom Models` and the Duration `Custom` setting are separate features and keep their names.
- Condensed `SKILL.md`, the reference index, and README; synchronized website guidance and harness metadata.
- Expanded web docs with cover-art and validation pages, a worked song matrix, current heuristic slider ranges, take logs, and linked reference files; checked all 19 routes at desktop and mobile sizes.
- Made section counts, genre fusion roles, compact prompts, and slider recipes explicit starting choices instead of universal requirements.

### Fixed

- Removed mandatory chorus simplification, fixed switch-count limits, and automatic transformation of the user's draft. Qualified Rule of 3 and 80/20 as optional heuristics.
- Distinguished Afrobeats from amapiano palette assumptions, funk from disco, phonk branches, and metalcore from heavy music as a whole.

- Recorded Variety in the Advanced tab, confirmed by the user on 2026-09-24; synchronized control guidance, output templates, and web docs.

- Made the no-em-dash and no-en-dash rule explicit for every generated field and surrounding prose, with a final character scan and punctuation regression cases.

- Removed unverified Variety defaults and deterministic-comparison claims; rechecked the official v6 model, release overview, and FAQ sources on 2026-09-24.

- Rewrote `references/personas.md` around what Suno actually provides, confirmed against the shipped UI. Voices and Style Personas are one surface, not two: Style Personas sits in the Voices menu and opens `Create a Voice` (Beta), taking a recorded or uploaded sample of at least 10 seconds, with older Personas converted into that library and reached through `Select from library`. Suno's Voices article still states a 15 second minimum and the Personas button it replaced disappeared back in the v5.5 release of 2026-03-26, so this guidance was stale twice over. The Personas button became Voices in the v5.5 release of 2026-03-26, with Style Personas nested inside it, meaning this guidance was already stale before v6. The file now separates the Markdown spec (a portable brief that selects nothing) from Voices (a verified clone of a real human voice, usable only by its creator), Style Personas, and Custom Models, and tells the agent to confirm the user's Voices menu rather than trusting the help center.
- Replaced the invented heading `Cover / Remix / Restyle` with Suno's documented structure: Remix is the umbrella over Cover, Extend, Reuse, and Speed. There is no tool called Restyle.
- Propagated the Variety rule to every place that depended on a Style line surviving generation: the take-comparison rule in `references/studio-and-iteration.md`, style matching in `references/remix-and-style-match.md`, and the `Suno Defaults` block of both the persona and album spec templates, which now pin `Model` and `Variety: 0` so a saved identity stays reproducible.
- Corrected this session's own claim that the Variety slider was undocumented. Suno's v6 FAQ documents both the mechanism ("adjusting and updating your style prompts") and the fix ("reduce the Variety slider to 0"), so that guidance is now sourced rather than hedged. The intermediate stop labels and per-model defaults remain a single unverified community report and are labeled as such.
- Recorded the measured-not-specified status of field character limits: Suno publishes none, and community counter readings converge on 5,000 Lyrics and 1,000 Styles and Exclude Styles.
- Replaced three help-center citations retired with their models (the v5.5 overview, the per-model song-length article, and the V4.5 detailed-style article) with live v6 sources; the guidance they supported was kept and re-anchored.
- Stated that sliders and square brackets do not belong in the Style field. Slider values are Advanced controls and brackets are lyrics syntax; both are read as ordinary prompt text in Style.
- Corrected the blanket claim that instrumental tracks cannot use Custom Mode Styles, Exclude, or sliders. Portable instrumental labels remain the default.
- Removed unsupported universal character limits, guaranteed ending claims, hidden-filter diagnoses from bland audio, and automatic voice assumptions.
- Distinguished earlier Duration and cover-tool UI observations from currently verified platform behavior.

## v1.2.1: 2026-07-31

### Changed

- Prose sweep across `SKILL.md` and all of `references/`: removed 200+ em-dashes (rewritten as colons, commas, parentheticals, or sentence splits), unified numeric ranges and taught Suno tag syntax on plain hyphens, replaced `seamlessly` and `genuinely` filler, and converted bold list labels from period to colon form. Added a voice spec recording the repo voice and carve-outs (Title Case headings, `underscore` as a musical term, semicolon-dense rule lists).

## v1.2.0: 2026-07-31

### Added

- MIT license: `LICENSE` filled in and `license: MIT` added to `SKILL.md` frontmatter (Claude Desktop displays it on upload).
- Release packaging: `suno-songwriter.zip` attached to GitHub releases, containing the skill folder at the zip root (the layout Claude Desktop's skill upload and Codex's `~/.codex/skills/` both expect). README and docs gained per-app install instructions for Claude Desktop, Codex (app and CLI), and Claude Code.
- `docs/`: GitHub Pages documentation site: a single self-contained static page covering the output contract, workflow, modes, Suno v5.5 controls, and the reference index. README gained a Documentation link and generic install paths; README cleaned (em-dash removed).
- `references/genre-fusion.md`: multi-genre handling: fusion blends built as anchor + accent, mid-song genre switches cued in both `Style:` and section tags, and same-song genre versions with per-version Style/sliders and singability re-checks. Routed from `SKILL.md`, `references/templates.md`, and `references/genre-palettes.md`; smoke tests V5/V6 added to `references/evals.md`.

### Fixed

- Documented v5.5's Duration control (user-verified in the UI: Auto, or a Custom slider 0:10-6:00 in 5-second steps): recommend Custom for target cuts, match the written structure to the set time, add 5-15s headroom so the ending resolves, Crop to exact length. Noted in `SKILL.md` § Creative Sliders and the output contract's `Slider Suggestions:`, `references/suno-v55-controls.md` § Duration, and `references/screen-music.md` § Edit-Length Guidance. Also added the missing cross-genre fusion row to the Slider Recipes table that `references/genre-fusion.md` points to.
- Refreshed the Suno v5.5 currency stamp (v5.5 still current as of 2026-07; no v6) in `SKILL.md`, and recorded the model version stamp in `CLAUDE.md`.

- Tightened `SKILL.md` around hook-first lyric quality so vocal requests prioritize a strong song over a complete form: clear title/hook, simpler chorus, stable POV/tense, concrete detail, and singable line lengths.
- Shortened the trigger description and OpenAI default prompt to reduce metadata bloat and avoid steering every request into optional notes, sliders, and checks.
- Synced `references/output-templates.md`, `references/screen-music.md`, `references/evals.md`, `README.md`, and `CLAUDE.md` with the optional-field contract and lyric quality gate.
- Corrected Instrumental Mode guidance: Suno instrumentals use `Instrumental Prompt:` plus `Arrangement:`, not `Style:`, `Excluded Styles:`, or slider suggestions.
- Added a Suno-native lyric default: compact 4-line sections, short singable lines, plain rhyme, strong hook repetition, and optional performance descriptors in section tags.
- Added groove-narrative vocal mode for neo-soul/R&B/jazz-hop/spoken-sung songs with longer rhythmic verses, environmental arrangement cues, vocalist labels, spoken bridges, and simple chanted choruses.

## v1.1.0: 2026-05-12

### Added

- `references/cover-art.md`. Suno's **Generate Cover Art** / **Animate** tools: the three paths (text-to-image, text-to-video, image-to-video), controls and limits (Quality Mode, 5s/10s length, 1:1 square-only, ~800-char prompt fields, motion prompt, ~2 variants, ~5-min generation), matching the visual to the song's lane/era/mood/key image (and to a persona/album visual identity), image-prompt craft (subject/composition → medium/style → palette → lighting → mood; no text, logos, or real artist/character names; same filter logic as `Style:`), motion-prompt craft (motion only, loop-friendly, no morphing faces/hands or hard cuts), the `Cover Concept:` / `Image Prompt:` / `Motion Prompt:` / `Settings:` output shape plus the `Cover Art:` block appended to a song package, anti-AI-art-cliché guidance, and where it stops (full multi-scene music videos → external editor; Suno Scenes camera→song → normal song contract).
- `SKILL.md`: new "Cover Art And Animated Covers" section; routing entry; expanded frontmatter description (cover art / animated covers, plus a `cover art` casual trigger), trimmed elsewhere to stay ≤ 1024 chars.
- Wiring: `references/templates.md`, `README.md` (What It Covers, Files, Reference Loading Guide), `CLAUDE.md` (architecture reference list); `references/evals.md` smoke-test rows (CV1, CV2), should-trigger queries, and a regression check; synced to installed copy.

## v1.0.1: 2026-05-12

### Fixed

- `SKILL.md` `description:` frontmatter rewritten to **1019 characters** (was ~1900) and stripped of the `<artist>` angle-bracket token, so harnesses that validate the field (Claude Desktop) accept the skill. Trigger coverage preserved in plain prose. Documented the ≤ 1024-char / no-XML-tags constraint in `CLAUDE.md`.

## v1.0.0: 2026-05-12

First tagged release. Full surface: write / revise / remix lyrics; instrumentals; screen music (anime OP/ED, TV themes, trailers, idents, game themes); multilingual (incl. Korean lanes beyond K-pop); Suno controls, meta-tags, sliders, content filters, and Studio/iteration workflow; style-match ("in the style of X"); reusable artist personas; cohesive albums/EPs; and Suno Sounds (custom audio samples). Progressive-disclosure architecture: concise `SKILL.md` + 19 independently-loadable `references/*.md` files.

### Added

- Performance/energy descriptors inside section tags (e.g. `[Whispered Verse]`, `[Explosive Chorus, big guitars]`, `[Double-time Outro]`), documented in `SKILL.md` and expanded in `references/song-structure.md` with intensity / arrangement / delivery descriptor lists and usage rules.
- "No artist names" guidance: do not pass `sounds like <artist>` into `Style:`; translate the reference into era, scene, rhythm section, signature sound, and production character. Added to `SKILL.md` anti-generic rules, `references/suno-v55-controls.md` (new subsection plus a troubleshooting line), and `references/style-selection.md` (new "Translating Reference Artists" subsection).
- Three-anchor quick frame for the Style field (core genre / vibe-texture / lead or signature sound, then tempo, vocal, production) in `references/suno-v55-controls.md`.
- `CLAUDE.md` with repo overview, progressive-disclosure architecture notes, validation/sync commands, and content conventions.
- `references/suno-meta-tags.md`: inline lyric cues beyond section headers: instrumental moments (`[Guitar Solo]`, `[Beat Drop]`), vocal delivery (`[Spoken]`, `[Whispered]`, `[Harmonies]`), multiple vocalists (`[Male Voice]`, `[Female Voice]`, `[Duet]`), ad-libs, sound effects, `[End]`/`[Fade Out]` length control, and failure modes.
- `references/genre-palettes.md`: per-lane menu of BPM bands, signature instruments, production textures, vocal identities, and typical structures across pop, rock, hip hop, electronic, folk/country, soul/gospel, world/regional, score, and niche lanes; framed as a picker, not a set of defaults.
- `references/studio-and-iteration.md`: two-clips-per-run, Extend, Cover/Remix, Replace Section / Edit / inpainting, Crop, stems, remaster, and an edit-vs-re-roll decision table.
- `references/screen-music.md`: anime openings (TV-size form) and endings, TV theme songs / main titles / idents / stings / bumpers, end-credit / needle-drop songs, trailer cuts (three-beat structure), video-game themes, edit-length guidance (full / TV-size / sting / ident), and which formats are vocal songs vs instrumental cues.
- `references/remix-and-style-match.md`: the style-yes/expression-no copyright rule; lyric remix/flip mode; style-match ("in the style of X") mode with style-fingerprint extraction, safe use of web/search, and original-work generation; lyric-style analysis output; `Style Reference:` / `Remix Notes:` output additions and extra checks.
- `references/personas.md`: reusable artist personas: custom vs style-reference (no real names in prompts), the `personas/<slug>.md` spec-file schema (identity, vocals, cadence, lyrical fingerprint, sonic palette / Style kernel, excluded styles, Suno defaults, basis, song log), creating a persona, using one to write a song, output-contract additions, and the no-overwrite rule.
- `references/albums.md`: cohesive albums/EPs: the `albums/<slug>.md` spec-file schema (concept, shared sonic palette / Style kernel, cohesion rules, recurring elements, sequenced tracklist with roles, sequencing notes, excluded styles, Suno defaults, changelog), optional persona link, creating an album, writing a track for one, output-contract additions, and the no-overwrite rule.
- `references/suno-sounds.md`. Suno Sounds (custom audio samples): One Shot vs Loop, BPM, Key; sound categories (SFX & transitions, ambient/background, foley & action, animal, musical samples / drum kits) with example prompts; prompt-writing guidance (recognizable vocabulary, duration, material/space/motion/size); the `Sound:` / `Type:` / `BPM` / `Key` / `Variations` output shape; and the sample-vs-short-piece-of-music routing rule. Based on Suno help article 10625537.

### Changed

- `references/suno-v55-controls.md`: added a Title-field note, a Content-Filters section (real names, brands, profanity, graphic content can block or flatten a generation), an Iteration pointer, and new troubleshooting entries (blank/generic generation, mumbled vocals, model-invented verses, chorus-vs-verse contrast, pronunciation/accent drift).
- `references/songwriting-craft.md`: added "Point Of View And Tense" guidance, a note that the chorus must be mechanically (not just emotionally) plainer than the verses, and matching revision-checklist items.
- `references/instrumental.md`: added "Vocal Chops And Non-Lexical Vocals" (don't blanket-exclude vocals when wordless vocals are wanted), a "Stems And Handoff" note, an "Idents / Stings / Bumpers" micro-cue section, and cross-links to `references/screen-music.md`.
- `references/multilingual.md`: expanded Pronunciation (AI mispronunciation reality, in-line phonetic respelling, `Pronunciation Notes:` usage); broadened the Korean entry to cover ballad, K-hip hop / K-R&B, Korean indie/folk, OST, and trot beyond K-pop; cross-links to studio workflow and screen music.
- `references/genre-palettes.md`: added Korean ballad, K-hip hop / K-R&B, Korean indie/folk, trot, city pop, anime OP (J-rock/J-pop), anime ED, and TV theme / sitcom theme rows; added reminders that "Korean music" is broader than K-pop and that screen formats need `references/screen-music.md`.
- `references/style-selection.md`: added a "screen-tied song" row to the style-selection matrix and broadened the multilingual row (city pop, Korean ballad, K-hip hop, Korean indie, trot) with cross-links.
- `references/song-structure.md`: added a "Screen-Tied Forms" section (anime OP TV-size, anime ED / needle-drop, TV theme / sting, trailer cut).
- `SKILL.md`: expanded the frontmatter `description` (remix, Korean lanes beyond K-pop, anime OP/ED, TV themes, trailers, idents, game themes, lyric remix/flip, style-match, lyric-style analysis, reusable personas, cohesive albums/EPs, Suno Sounds samples; clarified that writing in an artist's style is in scope but reproducing their lyrics is not); added "Remix And Style-Match Mode", "Screen-Tied Songs And Cues", "Personas And Albums", and "Sound Samples (Suno Sounds)" sections; added a Core-Workflow note to load a named persona/album spec first; added routing entries for the new reference files.
- `references/evals.md`: new smoke-test rows (meta-tags, artist-reference rewrite, section descriptors, iteration/Replace-Section, genre-palette, anime OP, TV theme, Korean ballad, lyric remix, style-match, lyric-style analysis, persona custom/style-reference/use, album plan/track, Suno Sounds), new should-trigger queries, and new regression checks.
- `references/templates.md`, `README.md`, `CLAUDE.md`: routing/index entries for all eight new reference files; `SKILL.md` also gained an inline-meta-tags pointer, a content-filter caution, and a version/date anchor.

## Pre-1.0

- Renamed skill to `suno-songwriter`.
- Added skill smoke-test reference (`references/evals.md`).
- Added song structure reference.
- Added 80/20 songwriting reference.
- Initial Suno lyrics agent skill.
